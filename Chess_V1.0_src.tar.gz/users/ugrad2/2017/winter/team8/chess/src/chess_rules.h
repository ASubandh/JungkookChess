#ifndef CHESS_RULES_H
#define CHESS_RULES_H

#include "chess_move.h"
// #include "AI.h" // for checkmate
//int checkmate ( movelist,)
int kingcheck(int Cur_Position, int New_Position, int color);

#endif

