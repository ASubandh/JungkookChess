//game state header file - Abhishek Subandh
#ifndef CHESS_PIECE_STRUCTURE_H
#define CHESS_PIECE_STRUCTURE_H
#include "Constants.h"


int MainMenuState1();
int MainMenuState2();
int MainMenuState3();

#endif
