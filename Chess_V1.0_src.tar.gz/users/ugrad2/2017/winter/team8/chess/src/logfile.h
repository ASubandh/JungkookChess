#ifndef LOGFILE_H
#define LOGFILE_H

int logfile(int sentcurposition, int sentnewposition);

#endif
