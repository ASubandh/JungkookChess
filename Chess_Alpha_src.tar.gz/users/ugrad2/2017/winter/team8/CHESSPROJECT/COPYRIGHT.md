COPYRIGHT

All rights reserved to Women in Stem:
Abhishek Subandh
Kiran Vanuy
Yuxuan Lu
Roy Guan

This software is licensed under GNU Public License.
