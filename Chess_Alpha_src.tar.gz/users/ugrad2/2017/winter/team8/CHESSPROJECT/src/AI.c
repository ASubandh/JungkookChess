// AI draft
#include constants.h
#include stdl.h
#include stdio.h

// not compiled into chess because it will not work
// black pieces and white pieces have their own array
// that stores 


main(){

//look to see if queen, bishop, knight, rook have move options
// if (teammate piece is in the way of queen bishop) move
// evaluate by incrementing the piece location by 1 in both rank and file to check if location is pointing to empty or not
// if opponent moved pass the middle line, aim to castle
	// castle in the direction away from the mass amount of enemy pieces half
// move pawn that gives more move opportunities to queen, bishop, knight, rook
// save rook for castling
// don't move pieces into places where opponents can capture immediately next turn
// if a lot of directions randomize direction to move in and then decide what available spot is good
// if a high rank piece is in danger of being capture, move that piece
// eat high rank pieces the moment it is an opportunity
// eat queen no matter what, then bishop then rook
// eat piece when opportunity comes (and u dont get eaten)






 
}