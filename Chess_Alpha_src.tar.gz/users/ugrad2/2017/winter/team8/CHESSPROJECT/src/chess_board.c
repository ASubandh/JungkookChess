#include "chess_board.h"

char ChessBoard [8][50];
char SplitLine[] = "    +----+----+----+----+----+----+----+----+";
char EndLine[] = "       a    b    c    d    e    f    g    h";
char chess[8][50];
char s[1] = " ";

void Chess_board_default(){
	strcpy(ChessBoard[0],"8   |    |    |    |    |    |    |    |    |");
    strcpy(ChessBoard[1],"7   |    |    |    |    |    |    |    |    |");
	strcpy(ChessBoard[2],"6   |    |    |    |    |    |    |    |    |");
	strcpy(ChessBoard[3],"5   |    |    |    |    |    |    |    |    |");
	strcpy(ChessBoard[4],"4   |    |    |    |    |    |    |    |    |");
	strcpy(ChessBoard[5],"3   |    |    |    |    |    |    |    |    |");
	strcpy(ChessBoard[6],"2   |    |    |    |    |    |    |    |    |");
	strcpy(ChessBoard[7],"1   |    |    |    |    |    |    |    |    |");
}

void Chess_pieces_default(){
	int iStart = 6, i = 0, j = 0, k = 0;
	char piecesName[64][3] = {"bR","bN","bB","bQ","bK","bB","bN","bR",
	                          "bP","bP","bP","bP","bP","bP","bP","bP",
	                          "  ","  ","  ","  ","  ","  ","  ","  ",
	                          "  ","  ","  ","  ","  ","  ","  ","  ",
	                          "  ","  ","  ","  ","  ","  ","  ","  ",
	                          "  ","  ","  ","  ","  ","  ","  ","  ",
							  "wP","wP","wP","wP","wP","wP","wP","wP",
							  "wR","wN","wB","wQ","wK","wB","wN","wR"};
	int iPointY[4]={0,1,6,7};
	for (j=0;j<8;++j){
		for (i=0; i<8; ++i){
			strcpy(Pieces[j*8+i].Name,piecesName[j*8+i]); 
			Pieces[j*8+i].Position = j*8+1;
		}
	}
/*	for (k = 0; k < 64; ++k){
    	for(j = 0; j < 3; ++j){
        	printf("%c",board[k][j]);
    	}
    	printf("\n");
	}*/
}

void Get_board(){
	int i,j;
	for (i=0;i<8;++i){
		strcpy(chess[i],ChessBoard[i]);
	}
	for (j=0;j<8;++j){
		for (i=0;i<8;++i){
			chess[j][6+5*i] = Pieces[j*8+i].Name[0];
			chess[j][7+5*i] = Pieces[j*8+i].Name[1];
		} 
	}
}

void Print_board(){
	system("cls");
	int i;
	for (i=0; i<8; ++i){
		printf("%s\n",SplitLine);
		printf("%s\n",chess[i]);		
	}
	printf("%s\n",SplitLine);
	printf("%s\n",EndLine);
	system("pause");
}

void Clean_board(){
	system("cls");
}

void Move_Piece(int Cur_Position, int New_Position){
	Pieces[New_Position].Name[0] = Pieces[Cur_Position].Name[0];
	Pieces[New_Position].Name[1] = Pieces[Cur_Position].Name[1];
	Pieces[Cur_Position].Name[0]= s;
	Pieces[Cur_Position].Name[1]= s;
	// uncomplete 
}

