#ifndef CONSTANTS_H
#define CONSTANTS_H

#define ROW 8 
#define COL 8

#include<stdio.h> 
#include<time.h> 
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<assert.h>

#endif 
