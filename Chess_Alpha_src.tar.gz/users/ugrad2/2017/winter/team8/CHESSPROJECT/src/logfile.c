//logfile.c
//Prints out all the moves from the list into a document
//links to logfile.h, needs to be linked to main.c


#include <stdio.h>
#include "chess_piece_structure.h"

//#include "logfile.h" - do we even need a header file?

//final function
//int logfile (struct Chess_move moves);
//assert(moveList)
//}

int main() {
struct Chess_move moves;
FILE *file = fopen("C:\\Users\\Abhishek\\Desktop\\EECS\\EECS 22\\mychess\\logfile.txt", "w");

if (file == NULL) {
      printf("Error opening file!\n");
      fclose(file);
      }

for(int i=0; i<8; i++){
  const char *text = "Write this to the file";
  fprintf(file, "Some text: %s\n", text);
  }

fclose(file);
}
